"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ValDB = void 0;
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const uuid_1 = require("uuid");
const dbclient = new aws_sdk_1.default.DynamoDB.DocumentClient();
class ValDB {
    constructor() { }
    async put(tableName, body) {
        console.log(`${tableName}, ${body}`);
        return await dbclient.put({
            TableName: tableName,
            Item: Object.assign(Object.assign({}, body), { productID: (0, uuid_1.v4)() }),
        }).promise();
    }
}
exports.ValDB = ValDB;
//# sourceMappingURL=db.js.map